//
//  Titles.swift
//  TravelPP
//
//  Created by Neema on 10/28/20.
//  Copyright © 2020 Neema Philippe. All rights reserved.
//

import Foundation
 
enum NavBarTitle: String {
    case before = "Before Travel"
    case travelDay = "Travel Day"
    case home = "Home"
}
