# LetsTravel

This app serves as an organizational tool for travelers. The app is broken down into three categories: preparing to travel, traveling, and settling in post travel. 

Shown thus far is the travel day VC. This VC is broken down into four categories: 1) Parking Information , 2) Boarding Pass Upload (where the user can upload an image from their photo library), and 3) A button segueing to things to do in the city the user is traveling to.


